local http = require "summit.http"
local menu = require "summit.menu"
local speech = require "summit.speech"
local json = require "json"
local inspect = require "inspect" --repl()
local myJsonId = "4mzik";

channel.answer()

currentId = 1;
found = false;
choices = "";
digits = "";
children = {};

local res, err = http.get("https://api.myjson.com/bins/".. myJsonId, {});

myTable = json:decode(res.content);

function playChoices()
	return channel.gather({play=speech(choices)});
end

function findCorrectChoice()
	--for each of the children
	for i=1, #children do

		--if it was pushed
		if(digits == ""..i) then
			found = true;
			-- repl();
			--find the linked index in the data structure
			for j=1, #myTable do

				--if you find it set the current id and break
				if(myTable[j].id == children[i].Link) then
					currentId = j;
					do return end;
				end
			end
		end	
	end
end

channel.say("when choosing a number below press the number, then press the pound key.")

while(true) do

	-- say the first question
	channel.say(myTable[currentId].Question)
	children = myTable[currentId].Children;
	--repl();

	--IF THIS IS THE END break
	if(#children == 0) then
		break;
	end

	-- say all of the different choices
	choices = "";
	for i=1, #children do
		choices = choices.." For " .. children[i].Answer .. " Press "..i.." ";
	end
	choices = choices.." To hear these choices again press 0.";

	digits = playChoices()

	while digits == "0" do
		digits = playChoices()
	end

	found = false;
	findCorrectChoice();


	while(not found) do
		channel.say("the answer you entered was not valid, try again");
		digits = playChoices();
		while digits == "0" do
			digits = playChoices()
		end
		findCorrectChoice();
	end
end
channel.hangup()